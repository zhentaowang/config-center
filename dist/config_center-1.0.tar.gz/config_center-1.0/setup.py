#-*- coding: utf-8 -*-
#Created by Hans on 16-5-31

from distutils.core import setup
setup(
    name='config_center',
    version='1.0',
    author='Hans',
    author_email='464501551@qq.com',
    url='https://github.com/hansdcr',
    packages=['config_center','.']
)
